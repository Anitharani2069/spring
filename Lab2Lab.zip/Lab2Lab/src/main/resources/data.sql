insert into trainee values(101,'FSD','BANGALORE','SHUBHAM');
insert into trainee values(102,'V&V','CHENNAI','SURAJIT');
insert into trainee values(103,'RDBMS','PUNE','PRAVEEN');
insert into trainee values(104,'MAIN FRAME','MUMBAI','HARISH');
insert into trainee values(105,'COBAL','HYDERABAD','SAIBABU');