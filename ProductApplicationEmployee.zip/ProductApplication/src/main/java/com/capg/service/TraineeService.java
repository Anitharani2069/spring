package com.capg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.capg.bean.Trainee;
import com.capg.dao.TraineeDao;

public class TraineeService implements ITraineeService{

	@Autowired
	TraineeDao repo;

	@Override
	public Trainee addTrainee(Trainee tre) {
		// TODO Auto-generated method stub
		return repo.save(tre);
	}

	@Override
	public void deleteTraineeById(int traineeId) {
		// TODO Auto-generated method stub
		repo.deleteById(traineeId);
	}

	@Override
	public Trainee updateTrainee(Trainee tre) {
		// TODO Auto-generated method stub
		return repo.save(tre);
	}

	@Override
	public List<Trainee> retrieveTrainees() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}

	@Override
	public Trainee getTraineeById(int traineeId) {
		// TODO Auto-generated method stub
		return repo.findById(traineeId).orElse(new Trainee());
	}
	
	
}
