package com.capg.service;

import java.util.List;

import com.capg.bean.Trainee;

public interface ITraineeService {
	
	public Trainee addTrainee(Trainee tre);
	
	public void deleteTraineeById(int traineeId);
	
	public Trainee updateTrainee(Trainee tre);
	
	public List<Trainee> retrieveTrainees();

	public Trainee getTraineeById(int traineeId);
}
