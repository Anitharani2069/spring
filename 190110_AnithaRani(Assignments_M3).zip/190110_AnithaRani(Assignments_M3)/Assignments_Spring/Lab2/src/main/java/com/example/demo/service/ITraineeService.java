package com.example.demo.service;

import java.util.List;
import com.example.demo.pojo.Trainee;

public interface ITraineeService {
	
	public Trainee add(Trainee trainee);
	
	public Trainee find(int id);
	
	public List<Trainee> findAll();
	
	public void delete(int id);
	
	public void update(Trainee trn);
	
}
