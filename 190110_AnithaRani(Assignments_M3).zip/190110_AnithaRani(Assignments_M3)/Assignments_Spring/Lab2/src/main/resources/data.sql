insert into trainee values(101,'FSD','Banglore','Anitha');
insert into trainee values(102,'V&V','Kolkata','Raji');
insert into trainee values(103,'RDBMS','Chennai','TanuSri');
insert into trainee values(104,'MAIN FRAME','Pune','Yashaswi');
insert into trainee values(105,'COBAL','Mumbai','Tejaswini');