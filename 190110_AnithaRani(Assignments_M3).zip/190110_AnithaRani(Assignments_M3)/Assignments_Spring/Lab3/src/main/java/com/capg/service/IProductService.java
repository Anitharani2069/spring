package com.capg.service;

import java.util.List;

import com.capg.entities.Product;

public interface IProductService {
	
	public List<Product> prodList();
	
	public Product add(Product prod);

}
