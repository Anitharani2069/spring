package com.capg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.capg.bean.Product;
import com.capg.dao.ProductRepo;



@Service
public class ProdcutServiceImpl implements ProductService {
	
	@Autowired
	ProductRepo repo;

	@Override
	public List<Product> getProducts() {
		return repo.findAll();
	}

	@Override
	public void addProduct(Product product) {
		repo.save(product);
		
	}


	@Override
	public void deleteProduct(int id) {
		// TODO Auto-generated method stub
		repo.deleteById(id);
		
	}

	@Override
	public Product updateProduct(Product product) {
		// TODO Auto-generated method stub
		return repo.save(product);
	}

	

	
}
