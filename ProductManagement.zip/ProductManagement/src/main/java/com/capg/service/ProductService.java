package com.capg.service;

import java.util.List;

import com.capg.bean.Product;


public interface ProductService {
	
	public List<Product> getProducts() ;
	
	public void addProduct(Product product);
		
	public Product updateProduct(Product product);
	
	public void deleteProduct(int id) ;

}
