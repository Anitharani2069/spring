insert into product values(101,'Laptop',75000);
insert into product values(102,'IPad',55000);
insert into product values(103,'IPhone',45000);