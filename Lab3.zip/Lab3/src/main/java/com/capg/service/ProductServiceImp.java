package com.capg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.dao.ProductDao;
import com.capg.pojo.Product;

@Service
public class ProductServiceImp implements IProductService {
	
	@Autowired
	ProductDao repo;

	@Override
	public List<Product> prodList() {
		return repo.findAll();
	}

	@Override
	public Product add(Product prod) {
		return repo.save(prod);
	}

}
