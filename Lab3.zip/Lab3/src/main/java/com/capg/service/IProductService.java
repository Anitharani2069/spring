package com.capg.service;

import java.util.List;

import com.capg.pojo.Product;

public interface IProductService {
	
	public List<Product> prodList();
	
	public Product add(Product prod);

}
