insert into trainee values(101,'FSD','BANGALORE','ANITHA');
insert into trainee values(102,'V&V','CHENNAI','TANU SRI');
insert into trainee values(103,'RDBMS','PUNE','YASH');
insert into trainee values(104,'MAIN FRAME','MUMBAI','YOGITHA');
insert into trainee values(105,'COBAL','HYDERABAD','TEJU');