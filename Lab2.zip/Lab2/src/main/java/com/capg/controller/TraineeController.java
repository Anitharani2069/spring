package com.capg.controller;

public class TraineeController {

}
