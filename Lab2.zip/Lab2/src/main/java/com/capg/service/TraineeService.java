package com.capg.service;

public class TraineeService {

}
