package com.capg.dao;

public class TraineeDao {

}
