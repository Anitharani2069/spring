package com.example.demo.service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.TraineeDao;
import com.example.demo.pojo.Trainee;

@Service
public class TraineeServiceImp implements ITraineeService {
	
	@Autowired
	TraineeDao repo;

	@Override
	public Trainee add(Trainee trainee) {
		return repo.save(trainee);
	}

	@Override
	public Trainee find(int id) {
		return repo.findById(id).orElse(null);
	}

	@Override
	public List<Trainee> findAll() {
		return (List<Trainee>) repo.findAll();
	}

	@Override
	public void delete(int id) {
		repo.deleteById(id);
		
	}

	@Override
	public void update(Trainee trn) {
		repo.save(trn);
		
	}

}
