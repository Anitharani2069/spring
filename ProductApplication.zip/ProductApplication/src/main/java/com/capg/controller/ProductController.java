package com.capg.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capg.bean.Product;
import com.capg.service.IProductService;

@RestController
public class ProductController {
	
	
	@Autowired
	IProductService service;
	
	
	@GetMapping(path="/products",produces="application/json")
	public List<Product> getAllProducts() {
		// TODO Auto-generated method stub
		return service.getAllProducts();
	}
	
	
	@PostMapping(path="/addproduct",consumes="application/json")
	public Product addProduct(@RequestBody Product pro) {
	return service.add(pro);
	}
	
	
	@PutMapping(path="/updateproduct",consumes="application/json")
	public String updateProduct(@Valid @RequestBody Product pro) {
		service.update(pro);
		return "Updated Succesfully";
	}
	
	
	@DeleteMapping(path="/deleteproduct/{productId}") 
	public void deleteProduct(@PathVariable int productId) {
		service.deleteByPID(productId);
	}
	
	
}


