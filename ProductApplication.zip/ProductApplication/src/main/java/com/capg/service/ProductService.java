package com.capg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.bean.Product;
import com.capg.dao.ProductDao;



@Service
public class ProductService implements IProductService{
	
	@Autowired
	ProductDao repo;
	
	@Override
	public List<Product> getAllProducts() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}

	@Override
	public Product add(Product pro) {
		// TODO Auto-generated method stub
		return repo.save(pro);
	}

	@Override
	public Product update(Product pro) {
		// TODO Auto-generated method stub
		return repo.save(pro);
	}

	@Override
	public void deleteByPID(int productId) {
		repo.deleteById(productId);
	}
	
	
	
	
	
}
