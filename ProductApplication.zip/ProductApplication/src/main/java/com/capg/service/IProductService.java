package com.capg.service;

import java.util.List;

import com.capg.bean.Product;

public interface IProductService {
	
	public List<Product> getAllProducts();
	public Product add(Product pro);
	public Product update(Product pro);
	public void deleteByPID(int productId);
}
