package com.capg.bean;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.Max;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.stereotype.Component;


@Component
@Entity
public class Product {
	
	@Id
	@NotNull
	private int productId;
	@NotNull
	@Size(min=3,max=20,message="ProductName must be between 3 and 20")
	private String productName;
	@NotNull
	@Max(value=90000,message="price must be maximum 90000 and less than 90000")
	private double productPrice;
	@NotNull
	@Size(min=10,max=10,message="Mobile Number should be 10 digit")
	private long mobileNo;
	
	
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public double getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(double productPrice) {
		this.productPrice = productPrice;
	}
	public long getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(long mobileNo) {
		this.mobileNo = mobileNo;
	}
	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName=" + productName + ", productPrice=" + productPrice
				+ ", mobileNo=" + mobileNo + "]";
	}
	
	
	
	
}
